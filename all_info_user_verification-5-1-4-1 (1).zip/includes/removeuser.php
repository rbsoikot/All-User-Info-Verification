<?php
// Action to remove a user from the verified users list

add_action('admin_action_remove_verified_user', 'remove_verified_user');

function remove_verified_user() {
    if (isset($_GET['user_id'])) {
        $user_id = absint($_GET['user_id']);
        
        // Remove verification metadata
        delete_user_meta($user_id, 'email_verified');
        delete_user_meta($user_id, 'phone_verified');
        delete_user_meta($user_id, 'billing_phone');
        
        // Remove NID-related metadata
        delete_user_meta($user_id, 'nid_uploaded'); // Remove the NID uploaded status
        delete_user_meta($user_id, 'nid_file_url'); // Remove the NID file URL
        
        // Get the NID file URL from user meta
        $nid_file_url = get_user_meta($user_id, 'nid_file_url', true);

        // If the NID file URL exists, delete the file from the server
        if ($nid_file_url) {
            // Get the file path from the URL
            $file_path = str_replace(home_url('/'), ABSPATH, $nid_file_url);
            
            // Check if the file exists and delete it
            if (file_exists($file_path)) {
                unlink($file_path); // Delete the file from the server
            }
        }

        // Redirect back to the verified users page
        wp_redirect(admin_url('admin.php?page=verified-users'));
        exit;
    }
}
