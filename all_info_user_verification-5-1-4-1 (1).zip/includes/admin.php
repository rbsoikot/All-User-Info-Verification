<?php

function display_verified_users() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    $items_per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $items_per_page;
    $search_query = isset($_GET['search_query']) ? sanitize_text_field($_GET['search_query']) : '';
    $status_filter = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';
    $product_filter = isset($_GET['product_filter']) ? intval($_GET['product_filter']) : '';
    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '';
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '';

    // Meta query for email and phone verification
    $meta_query = array(
        'relation' => 'AND',
        array(
            'key' => 'email_verified',
            'value' => '1',
            'compare' => '='
        ),
        array(
            'key' => 'phone_verified',
            'value' => '1',
            'compare' => '='
        )
    );

    // Add status filter to the meta query if provided
    if (!empty($status_filter)) {
        if ($status_filter === 'pending') {
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key' => 'user_status',
                    'value' => 'pending',
                    'compare' => '='
                ),
                array(
                    'key' => 'user_status',
                    'compare' => 'NOT EXISTS'
                )
            );
        } else {
            $meta_query[] = array(
                'key' => 'user_status',
                'value' => $status_filter,
                'compare' => '='
            );
        }
    }

    // Base arguments for get_users
    $args = array(
        'number' => $items_per_page,
        'offset' => $offset,
        'meta_query' => $meta_query,
        'orderby' => 'registered', // Order by registration date
        'order' => 'DESC',         // Show newest users first
    );

    // Add search query if provided
    if (!empty($search_query)) {
        $args['search'] = '*' . esc_attr($search_query) . '*';
        $args['search_columns'] = array('user_login', 'user_nicename', 'user_email');
    }

    // Handle product and date filters
    if (!empty($product_filter) || !empty($start_date) || !empty($end_date)) {
        $order_query_args = array(
            'post_type'   => 'shop_order',
            'post_status' => 'wc-completed',
            'posts_per_page' => -1,
            'fields'      => 'ids',
            'date_query'  => array()
        );

        if (!empty($start_date)) {
            $order_query_args['date_query'][] = array(
                'after' => $start_date
            );
        }
        if (!empty($end_date)) {
            $order_query_args['date_query'][] = array(
                'before' => $end_date
            );
        }

        $orders = get_posts($order_query_args);
        $user_ids = array();

        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);

            foreach ($order->get_items() as $item) {
                if (!empty($product_filter) && $item->get_product_id() == $product_filter) {
                    $user_ids[] = $order->get_user_id();
                }
            }
        }

        $user_ids = array_filter(array_unique($user_ids));
        if (!empty($user_ids)) {
            $args['include'] = $user_ids;
        } else {
            $args['include'] = array(0); // No users found
        }
        
       

    }
    
    
    
function export_verified_users_csv() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    // Clear any previous output
    ob_clean();
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename=verified_users.csv');
    
    $output = fopen('php://output', 'w');

    // Column headers
    fputcsv($output, array('User ID', 'Name', 'Email', 'Last Purchase Date', 'Phone', 'NID File', 'Birth Certificate', 'Profile Picture', 'Status'));

    // Fetch filter parameters from the request
    $search_query = isset($_GET['search_query']) ? sanitize_text_field($_GET['search_query']) : '';
    $status_filter = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : '';
    $product_filter = isset($_GET['product_filter']) ? intval($_GET['product_filter']) : '';
    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '';
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '';

    // Meta query for email and phone verification
    $meta_query = array(
        'relation' => 'AND',
        array(
            'key' => 'email_verified',
            'value' => '1',
            'compare' => '='
        ),
        array(
            'key' => 'phone_verified',
            'value' => '1',
            'compare' => '='
        )
    );

    // Add status filter to the meta query if provided
    if (!empty($status_filter)) {
        if ($status_filter === 'pending') {
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key' => 'user_status',
                    'value' => 'pending',
                    'compare' => '='
                ),
                array(
                    'key' => 'user_status',
                    'compare' => 'NOT EXISTS'
                )
            );
        } else {
            $meta_query[] = array(
                'key' => 'user_status',
                'value' => $status_filter,
                'compare' => '='
            );
        }
    }

    // Base arguments for get_users
    $args = array(
        'number' => -1, // Get all users
        'meta_query' => $meta_query,
        'orderby' => 'registered', // Order by registration date
        'order' => 'DESC',         // Show newest users first
    );

    // Add search query if provided
    if (!empty($search_query)) {
        $args['search'] = '*' . esc_attr($search_query) . '*';
        $args['search_columns'] = array('user_login', 'user_nicename', 'user_email');
    }

    // Handle product and date filters
    if (!empty($product_filter) || !empty($start_date) || !empty($end_date)) {
        $order_query_args = array(
            'post_type'   => 'shop_order',
            'post_status' => 'wc-completed',
            'posts_per_page' => -1,
            'fields'      => 'ids',
            'date_query'  => array()
        );

        if (!empty($start_date)) {
            $order_query_args['date_query'][] = array(
                'after' => $start_date
            );
        }
        if (!empty($end_date)) {
            $order_query_args['date_query'][] = array(
                'before' => $end_date
            );
        }

        $orders = get_posts($order_query_args);
        $user_ids = array();

        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);

            foreach ($order->get_items() as $item) {
                if (!empty($product_filter) && $item->get_product_id() == $product_filter) {
                    $user_ids[] = $order->get_user_id();
                }
            }
        }

        $user_ids = array_filter(array_unique($user_ids));
        if (!empty($user_ids)) {
            $args['include'] = $user_ids;
        } else {
            $args['include'] = array(0); // No users found
        }
    }

    // Fetch users based on the arguments
    $users = get_users($args);

    foreach ($users as $user) {
        $profile_picture = get_user_meta($user->ID, 'profile_picture', true);
        $nid_file_url = get_user_meta($user->ID, 'nid_file_url', true);
        $birth_certificate_url = get_user_meta($user->ID, 'birth_certificate_url', true);
        $billing_phone = get_user_meta($user->ID, 'billing_phone', true);
        $status = get_user_meta($user->ID, 'user_status', true);
        $status = $status ? $status : 'pending';

        // Fetch last purchase date
        $latest_order = wc_get_orders(array(
            'limit' => 1,
            'customer_id' => $user->ID,
            'orderby' => 'date_created',
            'order' => 'DESC',
        ));
        $latest_purchase_date = !empty($latest_order) ? $latest_order[0]->get_date_created()->format('Y-m-d H:i:s') : 'No Purchases';

        // Add user data to CSV
        fputcsv($output, array(
            $user->ID,
            $user->display_name,
            $user->user_email,
            $latest_purchase_date,
            $billing_phone ? $billing_phone : 'Not Provided',
            $nid_file_url ? $nid_file_url : 'Not Uploaded',
            $birth_certificate_url ? $birth_certificate_url : 'Not Uploaded',
            $profile_picture ? $profile_picture : 'Not Uploaded',
            ucfirst($status)
        ));
    }

    fclose($output);
    
    // Ensure no extra output is sent
    exit;
}
    
    
    
    
    
    
    
    
    

    // Fetch users based on the arguments
    $users = get_users($args);
    $total_users = count(get_users(array_merge($args, array('number' => -1, 'offset' => 0))));

    // Handle saving the note for a user
    if (isset($_POST['save_note']) && isset($_POST['user_id'])) {
        $user_id = intval($_POST['user_id']);
        $user_notes = sanitize_textarea_field($_POST['user_notes']);
        update_user_meta($user_id, 'user_notes', $user_notes); // Save note in user meta
        wp_redirect($_SERVER['REQUEST_URI']); // Reload the page to show the updated content
        exit;
    }

    // Handle sending an email to a user
    if (isset($_POST['send_email']) && isset($_POST['user_id']) && isset($_POST['email_content'])) {
        $user_id = intval($_POST['user_id']);
        $user_email = get_userdata($user_id)->user_email;
        $subject = 'Important Information';
        $message = nl2br(esc_html($_POST['email_content'])); // Convert newlines to <br> tags and escape HTML

        // Define headers for HTML content
        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send the email
        wp_mail($user_email, $subject, $message, $headers);

        // Reload the page after sending the email
        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }

    // Handle toggling user status
    if (isset($_POST['toggle_status']) && isset($_POST['user_id']) && current_user_can('manage_options')) {
        $user_id = intval($_POST['user_id']);
        $current_status = sanitize_text_field($_POST['current_status']);
        $new_status = ($current_status === 'active') ? 'pending' : 'active';
        update_user_meta($user_id, 'user_status', $new_status);
        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }
    
     if (isset($_GET['export_csv'])) {
            export_verified_users_csv();
        }

    // Display the user table and filters
    ?>
    <div class="wrap" style="background-color: #f9f9f9; padding: 20px; border-radius: 8px;">
        <h2 style="font-family: 'Poppins', sans-serif; font-weight: 600; font-size: 24px; color: #333;">Verified Users</h2>

        <form method="get" style="margin-bottom: 20px; display: flex; flex-wrap: wrap; align-items: center;">
            <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page']); ?>">
            <input type="text" name="search_query" value="<?php echo esc_attr($search_query); ?>" placeholder="Search by Name or Email" style="width: 300px; padding: 10px; margin-right: 10px; border-radius: 4px; border: 1px solid #ccc; font-size: 14px;" />
            
            <select name="status_filter" style="padding: 10px; border-radius: 4px; border: 1px solid #ccc; margin-right: 10px;">
                <option value="">All Statuses</option>
                <option value="active" <?php selected($status_filter, 'active'); ?>>Active</option>
                <option value="pending" <?php selected($status_filter, 'pending'); ?>>Pending</option>
            </select>

            <select name="product_filter" style="padding: 10px; border-radius: 4px; border: 1px solid #ccc; margin-right: 10px;">
                <option value="">All Products</option>
                <?php
                $products = wc_get_products(array('limit' => -1));
                foreach ($products as $product) {
                    echo '<option value="' . esc_attr($product->get_id()) . '" ' . selected($product_filter, $product->get_id(), false) . '>' . esc_html($product->get_name()) . '</option>';
                }
                ?>
            </select>

            <label for="start_date" style="margin-right: 5px;">Start Date:</label>
            <input type="date" name="start_date" value="<?php echo esc_attr($start_date); ?>" style="padding: 10px; border-radius: 4px; border: 1px solid #ccc; margin-right: 10px;">

            <label for="end_date" style="margin-right: 5px;">End Date:</label>
            <input type="date" name="end_date" value="<?php echo esc_attr($end_date); ?>" style="padding: 10px; border-radius: 4px; border: 1px solid #ccc; margin-right: 10px;">

            <button type="submit" class="button" style="background-color: #007cba; color: #fff; border: none; padding: 10px 15px; border-radius: 4px; font-size: 14px; transition: background-color 0.3s ease;">
                Filter
            </button>
            
            <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page']); ?>">
            <button type="submit" name="export_csv" class="button button-primary" style="background-color: #28a745; color: #fff; padding: 10px 15px; border-radius: 4px; font-size: 14px;margin:20px;">
                Download CSV
            </button>
                    
            
            
            
            
        </form>

        <table class="wp-list-table widefat fixed striped users" style="width: 100%; border-collapse: collapse; box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);">
            <thead>
                <tr style="background-color: #f1f1f1; font-weight: 600; color: #333;">
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">User ID</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Name</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Email</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Last Purchase Date</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Phone</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">NID File</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Birth Certificate</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Profile Picture</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Status</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Actions</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Send Email</th>
                    <th style="padding: 12px 15px; border: 1px solid #ddd;">Note</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($users)) {
                    foreach ($users as $user) {
                        $profile_picture = get_user_meta($user->ID, 'profile_picture', true);
                        $nid_file_url = get_user_meta($user->ID, 'nid_file_url', true);
                        $birth_certificate_url = get_user_meta($user->ID, 'birth_certificate_url', true);
                        $billing_phone = get_user_meta($user->ID, 'billing_phone', true);
                        $status = get_user_meta($user->ID, 'user_status', true);
                        $user_notes = get_user_meta($user->ID, 'user_notes', true);
                        $status = $status ? $status : 'pending';

                        // Fetch the latest purchase date
                        $latest_order = wc_get_orders(array(
                            'limit' => 1,
                            'customer_id' => $user->ID,
                            'orderby' => 'date_created',
                            'order' => 'DESC',
                        ));
                        $latest_purchase_date = !empty($latest_order) ? $latest_order[0]->get_date_created()->format('Y-m-d H:i:s') : 'No Purchases';
                        ?>
                        <tr style="background-color: #fff; transition: background-color 0.3s ease;">
                            <td style="padding: 10px 15px; border: 1px solid #ddd;"><?php echo esc_html($user->ID); ?></td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;"><?php echo esc_html($user->display_name); ?></td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;"><?php echo esc_html($user->user_email); ?></td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;"><?php echo esc_html($latest_purchase_date); ?></td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;"><?php echo esc_html($billing_phone ? $billing_phone : 'Not Provided'); ?></td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <?php if ($nid_file_url): ?>
                                    <a href="<?php echo esc_url($nid_file_url); ?>" target="_blank" style="color: #007cba; text-decoration: none;">View NID</a>
                                <?php else: ?>
                                    Not Uploaded
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <?php if ($birth_certificate_url): ?>
                                    <a href="<?php echo esc_url($birth_certificate_url); ?>" target="_blank" style="color: #007cba; text-decoration: none;">View Birth Certificate</a>
                                <?php else: ?>
                                    Not Uploaded
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <?php if ($profile_picture): ?>
                                    <a href="<?php echo esc_url($profile_picture); ?>" target="_blank">
                                        <img src="<?php echo esc_url($profile_picture); ?>" alt="Profile Picture" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;">
                                    </a>
                                <?php else: ?>
                                    Not Uploaded
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>" />
                                    <input type="hidden" name="current_status" value="<?php echo esc_attr($status); ?>" />
                                    <button type="submit" name="toggle_status" class="button <?php echo $status === 'active' ? 'button-primary' : 'button-secondary'; ?>" style="padding: 8px 12px; border-radius: 4px; font-size: 14px; background-color: <?php echo $status === 'active' ? '#28a745' : '#f0ad4e'; ?>; color: white; border: none; transition: background-color 0.3s ease;">
                                        <?php echo $status === 'active' ? 'Active' : 'Pending'; ?>
                                    </button>
                                </form>
                            </td>
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <a href="<?php echo admin_url('user-edit.php?user_id=' . $user->ID); ?>" style="color: #007cba; text-decoration: none; padding: 5px;">Edit</a> |
                                <a href="<?php echo admin_url('users.php?action=remove_verified_user&user_id=' . $user->ID); ?>" onclick="return confirm('Are you sure you want to remove this user from verified list?');" style="color: #d9534f; text-decoration: none; padding: 5px;">Remove Verification</a>
                            </td>
                            
                            <!-- Add the Email button -->
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <button class="open-popup-btn" onclick="openPopup()">Send Email</button>
                                <div class="popup-container" id="popupContainer">
                                    <div class="popup">
                                      <form method="post" style="display: inline; max-width: 600px;">
                                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>" />
                                        
                                        <!-- Textarea for editing the email content -->
                                        <textarea name="email_content" rows="10" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                                    <?php 
                                    // Strip HTML tags to display plain text in the textarea
                                    echo wp_strip_all_tags("
                                    Dear User,<br><br>
                                    We have noticed that the information you submitted does not meet the required criteria, which is why your submission is currently pending.<br><br>
                                    To resolve this issue and complete the process, please contact our support team for assistance. Our support team will help you with any updates or corrections that need to be made to your information.<br><br>
                                    Thank you for your understanding, and we look forward to assisting you.<br><br>
                                    --<br>
                                    © 2025 mexemy. All Rights Reserved.
                                    ");
                                    ?>
                                        </textarea>
                                        
                                        <!-- Submit button -->
                                        <button type="submit" name="send_email" class="button" style="background-color: #007cba; color: #fff; border: none; padding: 8px 12px; border-radius: 4px; margin-top: 10px;">
                                            Send Email
                                        </button>
                                    </form>



                                      <button onclick="closePopup()">Close</button>
                                    </div>
                                  </div>
                            </td>
                             <!-- Add the Note section -->
                            <td style="padding: 10px 15px; border: 1px solid #ddd;">
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>" />
                                    <textarea name="user_notes" placeholder="Enter a note" rows="3" style="width: 100%; border: 1px solid #ddd; padding: 5px;"><?php echo esc_textarea($user_notes); ?></textarea>
                                    <button type="submit" name="save_note" class="button" style="background-color: #17a2b8; color: #fff; border: none; padding: 8px 12px; border-radius: 4px; margin-top: 5px;">
                                        Save Note
                                    </button>
                                </form>
                            </td>
                            
                            
                            
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="10" style="text-align: center; padding: 20px;">No verified users found.</td></tr>';
                }
                ?>
            </tbody>
        </table>
           <style>
  
    .popup-container {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .popup {
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
      width: 300px;
    }

    .popup h2 {
      margin-top: 0;
    }

    .popup button {
      margin-top: 10px;
      padding: 10px 20px;
      border: none;
      background: #007bff;
      color: #fff;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }

    .popup button:hover {
      background: #0056b3;
    }

    .open-popup-btn {
      padding: 10px 20px;
      border: none;
      background: #28a745;
      color: #fff;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
    }

    .open-popup-btn:hover {
      background: #218838;
    }
  
  </style>
        
        <script>
         function openPopup() {
      document.getElementById('popupContainer').style.display = 'flex';
    }

    function closePopup() {
      document.getElementById('popupContainer').style.display = 'none';
    }
        </script>

        <?php
        $total_pages = ceil($total_users / $items_per_page);

        if ($total_pages > 1) {
            echo '<nav style="text-align: right; margin: 20px 0;">';
            $pagination_links = paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '?paged=%#%',
                'current' => $current_page,
                'total' => $total_pages,
                'prev_text' => __('« Previous'),
                'next_text' => __('Next »'),
                'type' => 'array',
            ));

            if (is_array($pagination_links)) {
                echo '<ul style="display: inline-flex; list-style: none; padding: 0; margin: 0;">';
                foreach ($pagination_links as $link) {
                    echo '<li style="margin: 0 5px;">';
                    echo str_replace(
                        'class="',
                        'style="display: block; padding: 8px 12px; text-decoration: none; background-color: #007cba; color: #fff; border-radius: 4px; transition: background-color 0.3s ease;" class="',
                        $link
                    );
                    echo '</li>';
                }
                echo '</ul>';
            }
            echo '</nav>';
        }
        ?>
    </div>
    <?php
      if (isset($_POST['toggle_status']) && isset($_POST['user_id']) && current_user_can('manage_options')) {
        $user_id = intval($_POST['user_id']);
        $current_status = sanitize_text_field($_POST['current_status']);
        $new_status = ($current_status === 'active') ? 'pending' : 'active';
        update_user_meta($user_id, 'user_status', $new_status);
        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }

}