


<?php

// Function to display the form to manually add a verified user
function add_verified_user_form() {
    // Check if the current user is an admin
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    ?>
    <div class="wrap">

        <!-- Form to add a manually verified user -->
        <h2 style="font-size: 24px; font-weight: bold; margin-bottom: 20px; color: #333;">Add Verified User Manually</h2>

        <form method="POST" enctype="multipart/form-data" style="border-radius: 8px; padding: 20px; width: 100%; max-width: 600px;">
            <div style="margin-bottom: 15px;">
                <label for="user_email" style="font-size: 14px; font-weight: 600; display: block; color: #555; margin-bottom: 5px;">Email:</label>
                <input type="email" id="user_email" name="user_email" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; color: #333; box-sizing: border-box;">
            </div>

            <div style="margin-bottom: 15px;">
                <label for="user_phone" style="font-size: 14px; font-weight: 600; display: block; color: #555; margin-bottom: 5px;">Phone:</label>
                <input type="text" id="user_phone" name="user_phone" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; color: #333; box-sizing: border-box;">
            </div>

            <div style="margin-bottom: 15px;">
                <label for="nid_file" style="font-size: 14px; font-weight: 600; display: block; color: #555; margin-bottom: 5px;">Upload NID File:</label>
                <input type="file" id="nid_file" name="nid_file" accept="image/jpeg, image/png, application/pdf" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; color: #333; box-sizing: border-box;">
            </div>

            <div style="margin-bottom: 15px;">
                <label for="birth_certificate" style="font-size: 14px; font-weight: 600; display: block; color: #555; margin-bottom: 5px;">Upload Birth Certificate:</label>
                <input type="file" id="birth_certificate" name="birth_certificate" accept="image/jpeg, image/png, application/pdf" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; color: #333; box-sizing: border-box;">
            </div>

            <div style="margin-bottom: 15px;">
                <label for="profile_picture" style="font-size: 14px; font-weight: 600; display: block; color: #555; margin-bottom: 5px;">Upload Profile Picture:</label>
                <input type="file" id="profile_picture" name="profile_picture" accept="image/jpeg, image/png" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; color: #333; box-sizing: border-box;">
            </div>

            <div style="margin-bottom: 15px;">
                <input type="submit" name="add_verified_user" value="Add Verified User" style="background-color: #007BFF; color: white; padding: 10px 15px; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; width: 100%; box-sizing: border-box;">
            </div>
        </form>

        <?php
        // Handle the form submission to manually add a verified user
        if (isset($_POST['add_verified_user'])) {
            $email = sanitize_email($_POST['user_email']);
            $phone = sanitize_text_field($_POST['user_phone']);
            $nid_file = $_FILES['nid_file'];
            $birth_certificate = $_FILES['birth_certificate'];
            $profile_picture = $_FILES['profile_picture'];

            // Check if user exists
            $user = get_user_by('email', $email);
            if ($user) {
                $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
                $upload_dir = wp_upload_dir();
                $upload_path = $upload_dir['basedir'] . '/uploads/';
                $upload_url = $upload_dir['baseurl'] . '/uploads/';

                if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0755, true);
                }

                
        // Handle NID file upload
        if ($nid_file && $nid_file['size'] > 0) {
            if (in_array($nid_file['type'], $allowed_types) && $nid_file['size'] <= 5 * 1024 * 1024) {
                $nid_filename = $user->ID . '-nid-' . time() . '-' . basename($nid_file['name']);
                $nid_file_path = $upload_path . $nid_filename;

                if (move_uploaded_file($nid_file['tmp_name'], $nid_file_path)) {
                    update_user_meta($user->ID, 'nid_uploaded', true);
                    update_user_meta($user->ID, 'nid_file_url', $upload_url . $nid_filename);
                } else {
                    echo '<div class="error"><p>Failed to upload the NID file. Please try again.</p></div>';
                }
            } else {
                echo '<div class="error"><p>Invalid NID file type or size. Please upload a JPG, PNG, or PDF file under 5MB.</p></div>';
            }
        }

        // Handle Birth Certificate upload
        if ($birth_certificate && $birth_certificate['size'] > 0) {
            if (in_array($birth_certificate['type'], $allowed_types) && $birth_certificate['size'] <= 5 * 1024 * 1024) {
                $bc_filename = $user->ID . '-bc-' . time() . '-' . basename($birth_certificate['name']);
                $bc_file_path = $upload_path . $bc_filename;

                if (move_uploaded_file($birth_certificate['tmp_name'], $bc_file_path)) {
                    update_user_meta($user->ID, 'birth_certificate_uploaded', true);
                    update_user_meta($user->ID, 'birth_certificate_url', $upload_url . $bc_filename);
                } else {
                    echo '<div class="error"><p>Failed to upload the Birth Certificate. Please try again.</p></div>';
                }
            } else {
                echo '<div class="error"><p>Invalid Birth Certificate file type or size. Please upload a JPG, PNG, or PDF file under 5MB.</p></div>';
            }
        }


                // Handle Profile Picture upload
                if ($_FILES['profile_picture']['size'] > 0) {
    $allowed_types = ['image/jpeg', 'image/png'];
    $profile_picture = $_FILES['profile_picture'];

    if (in_array($profile_picture['type'], $allowed_types) && $profile_picture['size'] <= 5 * 1024 * 1024) {
        $profile_picture_filename = $user->ID . '-profile-pic-' . time() . '-' . basename($profile_picture['name']);
        $profile_picture_path = $upload_path . $profile_picture_filename;

        if (move_uploaded_file($profile_picture['tmp_name'], $profile_picture_path)) {
            update_user_meta($user->ID, 'profile_picture', $upload_url . $profile_picture_filename);
        } else {
            echo '<div class="error"><p>Failed to upload the Profile Picture. Please try again.</p></div>';
        }
    } else {
        echo '<div class="error"><p>Invalid Profile Picture type or size. Please upload a JPG or PNG file under 5MB.</p></div>';
    }
}


                // Update user meta for verification
                update_user_meta($user->ID, 'email_verified', '1');
                update_user_meta($user->ID, 'phone_verified', '1');
                update_user_meta($user->ID, 'billing_phone', $phone);
                
                echo '<div class="updated"><p>User has been verified and files uploaded successfully!</p></div>';
            } else {
                echo '<div class="error"><p>User with this email does not exist.</p></div>';
            }
        }
        ?>
    </div>
    <?php
}
?>













