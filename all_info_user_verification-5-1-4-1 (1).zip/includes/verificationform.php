<?php

// Create a shortcode to display the verification page
add_shortcode('email_verification_form', 'email_verification_form_shortcode');

function email_verification_form_shortcode() {
    if (!is_user_logged_in()) {
        wp_redirect(home_url('/dashboard'));
    }

    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;

    $email_verified = get_user_meta($user_id, 'email_verified', true);
    $phone_verified = get_user_meta($user_id, 'phone_verified', true);
    // Get user email
    $email = wp_get_current_user()->user_email;

    // Get user phone (if stored in user meta)
    $phone = get_user_meta($user_id, 'billing_phone', true);

    // Redirect verified users (email and phone)
    if ($email_verified && $phone_verified) {
        wp_redirect(home_url()); // Redirect to homepage or any other page
        exit;
    }

    ob_start();
    ?>
<div class="verification-container" style="background-color: #FFFFFF; padding: 40px; border-radius: 12px; box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1); max-width: 600px; margin: 0 auto; font-family: 'Roboto', sans-serif;">
    
    <h2 style="text-align: left; font-size: 24px; color: #333333; font-weight: 700; margin-bottom: 20px;">Secure Your Account</h2>
    <p style="text-align: left; font-size: 16px; color: #666666; margin-bottom: 30px;">Verify your email and phone number to enhance the security of your account.</p>
    
    <button id="downloadBtn" style="margin-bottom:20px;">Download Verification Statement</button>
    </br>
    
     <!-- Add a link to trigger video popup -->
    <a href="javascript:void(0);" id="showVideoLink" style="color: #6E03EF; font-weight: bold; text-decoration: none; font-size: 16px; display: inline-block; padding: 10px 20px; border-radius: 6px; border: 2px solid #6E03EF; transition: all 0.3s ease;margin-bottom: 25px;">See How to Verify Yourself</a>

    <!-- Video Popup Section (Hidden by default) -->
    <div id="videoPopup" class="popup" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.8); display: flex; justify-content: center; align-items: center; z-index: 9999; padding: 20px;">
        <div class="popup-content" style="position: relative; padding: 30px; border-radius: 12px; width: 80%; max-width: 800px; text-align: center;  animation: fadeIn 0.5s ease;">
            <span id="closeBtn" class="close" style="position: absolute; top: 40px; right: 10px; font-size: 32px; cursor: pointer; background: transparent; border: none; font-weight: bold; transition: color 0.3s ease;">&times;</span>
            <h2 style="color:white;font-size:40px;">See How to Verify Yourself</h2>
            <!-- YouTube Embed Code -->
            <iframe width="760" height="415" src="https://www.youtube.com/embed/XzHGt-UiNQA?si=YmdQiPf8Kggus_1c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // When user clicks on the "See How to Verify Yourself" link
        $('#showVideoLink').click(function() {
            $('#videoPopup').fadeIn(); // Show the popup
        });

        // When user clicks the close button
        $('#closeBtn').click(function() {
            $('#videoPopup').fadeOut(); // Hide the popup
        });

        // Optional: Close the popup when clicking outside the video content area
        $('#videoPopup').click(function(event) {
            if ($(event.target).is('#videoPopup')) {
                $('#videoPopup').fadeOut(); // Hide the popup
            }
        });
    });
    document.getElementById('downloadBtn').addEventListener('click', function () {
      const link = document.createElement('a');
      link.href = 'https://teststage.mexemy.com/wp-content/uploads/2025/01/Mexemy-Official-1.pdf';
      link.download = 'Mexemy_Official_Statement.pdf'; // Suggested filename
      link.click();
    });
</script>

<style>
    /* Smooth fade-in animation for the popup */
    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }


    /* Close button hover effect */
    #closeBtn:hover {
        color: #6E03EF;
    }
</style>



    <!-- Email Verification Section -->
    <?php if (!$email_verified) : ?>
    <div id="email-verification-section" style="margin-bottom: 30px; padding: 20px; border-radius: 8px; border: 1px solid #EAEAEA; background: #F9F9F9;">
        <h3 style="color: #6E03EF; font-size: 18px; margin-bottom: 15px; font-weight: 600;">Email Verification</h3>
        
        <div style="display: flex; align-items: center; margin-bottom: 15px; gap: 10px;">
            <p style="font-size: 16px; color: #333333; font-weight: 500; margin: 0; flex: 0 0 auto;">Email:</p>
            <span style="font-size: 16px; color: #666666; word-wrap: break-word; flex: 1;"><?php echo esc_html($email); ?></span>
        </div>

        
        <button id="send-email-otp-btn" style="background-color: #6E03EF; color: #FFFFFF; border: none; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: 600; width: 100%; text-align: center; margin-bottom: 20px; transition: background-color 0.2s ease;">Send OTP</button>
        
        <div id="email-otp-section" style="display: none;">
            <label for="email-otp-input" style="font-size: 14px; color: #333333; margin-bottom: 8px; font-weight: 600;">Enter OTP:</label>
            <input type="text" id="email-otp-input" placeholder="Enter OTP" style="width: 100%; padding: 12px; border: 1px solid #EAEAEA; border-radius: 6px; font-size: 14px; margin-bottom: 10px;">
            <button id="verify-email-otp-btn" style="background-color: #6E03EF; color: #FFFFFF; border: none; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: 600; width: 100%; text-align: center;">Verify Email</button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Phone Verification Section -->
    <div id="phone-verification-section" style="display: <?php echo ($email_verified && !$phone_verified) ? 'block' : 'none'; ?>; padding: 20px; border-radius: 8px; border: 1px solid #EAEAEA; background: #F9F9F9;">
        <h3 style="color: #6E03EF; font-size: 18px; margin-bottom: 15px; font-weight: 600;">Phone Verification</h3>
        
        <div style="display: flex; align-items: center; margin-bottom: 15px;">
            <label for="phone-number" style="font-size: 16px; color: #333333; margin-right: 10px; width: 100px; font-weight: 500;">Phone:</label>
            <input type="text" id="phone-number" value="<?php echo esc_attr($phone); ?>" placeholder="Enter phone number" style="flex: 1; padding: 12px; border: 1px solid #EAEAEA; border-radius: 6px; font-size: 14px;">
        </div>
        
        <button id="send-phone-otp-btn" style="background-color: #6E03EF; color: #FFFFFF; border: none; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: 600; width: 100%; text-align: center; margin-bottom: 20px; transition: background-color 0.2s ease;">Send OTP</button>

        <div id="phone-otp-section" style="display: none;">
            <label for="phone-otp-input" style="font-size: 14px; color: #333333; margin-bottom: 8px; font-weight: 600;">Enter OTP:</label>
            <input type="text" id="phone-otp-input" placeholder="Enter OTP" style="width: 100%; padding: 12px; border: 1px solid #EAEAEA; border-radius: 6px; font-size: 14px; margin-bottom: 10px;">
            <button id="verify-phone-otp-btn" style="background-color: #6E03EF; color: #FFFFFF; border: none; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: 600; width: 100%; text-align: center;">Verify Phone</button>
        </div>
    </div>
</div>



    <script type="text/javascript">
    jQuery(document).ready(function($) {
    // Define ajaxurl if not available
    var ajaxurl = '<?php echo admin_url("admin-ajax.php"); ?>';
    var security_nonce = '<?php echo wp_create_nonce("otp_verification_nonce"); ?>'; // Create the nonce

    // Cooldown timers for email and phone OTPs
    var emailCooldown = [30, 60, 300]; // [30s, 1m, 5m] - in seconds
    var phoneCooldown = [30, 60, 300]; // [30s, 1m, 5m] - in seconds
    var emailOtpIndex = 0;
    var phoneOtpIndex = 0;

    // Function to update the button text based on cooldown time
    function updateOtpButton(button, cooldownTime) {
        button.prop('disabled', true); // Disable the button during cooldown
        button.text(' Please wait ' + cooldownTime + ' seconds before sending the next OTP '); // Update button text

        var countdown = setInterval(function() {
            cooldownTime--;
            button.text('Please wait ' + cooldownTime + ' seconds before sending the next OTP '); // Update button text

            if (cooldownTime <= 0) {
                clearInterval(countdown);
                button.prop('disabled', false); // Enable the button after cooldown
                button.text('Send OTP');
            }
        }, 1000);
    }

    // Email OTP handling
    $('#send-email-otp-btn').click(function() {
        // Check if the user needs to wait before sending another OTP
        if (emailOtpIndex < emailCooldown.length) {
            var waitTime = emailCooldown[emailOtpIndex];
            updateOtpButton($(this), waitTime);
            emailOtpIndex++; // Move to the next cooldown level
        }

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'send_otp',
                type: 'email',
                _wpnonce: security_nonce // Include the nonce
            },
            success: function(response) {
                $('#email-otp-section').show();
                $('#email-otp-result').text(response); // Show success or failure message
            },
            error: function(xhr) {
                alert('An error occurred: ' + xhr.status + ' ' + xhr.statusText);
            }
        });
    });

    $('#verify-email-otp-btn').click(function() {
        var otp = $('#email-otp-input').val();
        if (otp === '') {
            alert('Please enter OTP');
            return;
        }
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'verify_otp',
                type: 'email',
                otp: otp,
                _wpnonce: security_nonce // Include the nonce
            },
            success: function(response) {
                $('#email-otp-result').text(response); // Show success or failure message
                if (response.indexOf('successfully') !== -1) {
                    $('#email-verification-section').hide();
                    $('#phone-verification-section').show();
                }
            },
            error: function(xhr) {
                alert('An error occurred: ' + xhr.status + ' ' + xhr.statusText);
            }
        });
    });

    // Phone OTP handling
    $('#send-phone-otp-btn').click(function() {
        var phone = $('#phone-number').val();
        if (phone === '') {
            alert('Please enter your phone number');
            return;
        }

        // Check if the user needs to wait before sending another OTP
        if (phoneOtpIndex < phoneCooldown.length) {
            var waitTime = phoneCooldown[phoneOtpIndex];
            updateOtpButton($(this), waitTime);
            phoneOtpIndex++; // Move to the next cooldown level
        }

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'send_otp',
                type: 'phone',
                phone: phone,
                _wpnonce: security_nonce // Include the nonce
            },
            success: function(response) {
                $('#phone-otp-section').show();
                $('#phone-otp-result').text(response); // Show success or failure message
            },
            error: function(xhr) {
                alert('An error occurred: ' + xhr.status + ' ' + xhr.statusText);
            }
        });
    });

    $('#verify-phone-otp-btn').click(function() {
        var otp = $('#phone-otp-input').val();
        if (otp === '') {
            alert('Please enter OTP');
            return;
        }
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'verify_otp',
                type: 'phone',
                otp: otp,
                _wpnonce: security_nonce // Include the nonce
            },
            success: function(response) {
                $('#phone-otp-result').text(response); // Show success or failure message
                if (response.indexOf('successfully') !== -1) {
                    window.location.href = '/verification'; // Redirect after verification
                }
            },
            error: function(xhr) {
                alert('An error occurred: ' + xhr.status + ' ' + xhr.statusText);
            }
        });
    });
});

</script>

    <?php
    return ob_get_clean();
}
