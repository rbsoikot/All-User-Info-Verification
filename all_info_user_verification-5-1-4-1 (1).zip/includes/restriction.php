<?php

add_action('template_redirect', 'force_user_verification');
add_action('admin_init', 'force_user_verification');

function force_user_verification() {
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        $email_verified = get_user_meta($current_user->ID, 'email_verified', true);
        $phone_verified = get_user_meta($current_user->ID, 'phone_verified', true);

        // Allow access to the verification page and AJAX calls
        $current_url = esc_url_raw($_SERVER['REQUEST_URI']);
        if (strpos($current_url, '/email-and-phone-verification') !== false || (defined('DOING_AJAX') && DOING_AJAX)) {
            return; // Allow access to verification page or AJAX requests
        }

        // Redirect unverified users
        if (!$email_verified || !$phone_verified) {
            wp_redirect(home_url('/email-and-phone-verification'));
            exit;
        }
    }
}


//nid restriction