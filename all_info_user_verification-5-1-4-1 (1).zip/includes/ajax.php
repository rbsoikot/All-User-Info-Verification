<?php

// AJAX Handlers for OTPs
add_action('wp_ajax_send_otp', 'send_otp_function');
add_action('wp_ajax_verify_otp', 'verify_otp_function');

function send_otp_function() {
    // Verify nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'otp_verification_nonce')) {
        echo 'Invalid request.';
        wp_die();
    }

    $user_id = get_current_user_id();
    if ($user_id == 0) {
        echo 'User not logged in.';
        wp_die();
    }



     // Initialize attempts if not already set or reset after 24 hours
    if (!$otp_attempts || !$last_reset_time || ($current_time - $last_reset_time) > 86400) {
        $otp_attempts = 0;
        update_user_meta($user_id, 'otp_attempts', $otp_attempts);
        update_user_meta($user_id, 'otp_last_reset_time', $current_time);
    }
    
    
    
    
    $type = sanitize_text_field($_POST['type']);
    $otp = rand(100000, 999999);
    $otp_meta_key = ($type === 'email') ? 'email_verification_otp' : 'phone_verification_otp';
    $time_meta_key = ($type === 'email') ? 'email_otp_sent_time' : 'phone_otp_sent_time';

    $otp_expiry = 300; // Expiry in seconds (5 minutes)

    if ($type === 'email') {
        $email = wp_get_current_user()->user_email;
        $subject = 'Your Email OTP';
        $message = 'Your OTP is: ' . $otp . '. It will expire in 5 minutes.';
        wp_mail($email, $subject, $message);
        echo 'Email OTP sent successfully.';
    } else if ($type === 'phone') {
        $phone = sanitize_text_field($_POST['phone']);
        update_user_meta($user_id, 'billing_phone', $phone);

        // Send OTP via SMS service
        $response = send_sms($phone, "Your OTP is: $otp. It will expire in 5 minutes.", $otp);
        if ($response['status'] === 'failed') {
            echo 'Failed to send OTP via SMS. Please try again.';
            wp_die();
        } else {
            echo 'Phone OTP sent successfully.';
        }
    }

    // Save OTP and timestamp
    update_user_meta($user_id, $otp_meta_key, $otp);
    update_user_meta($user_id, $time_meta_key, time()); // Current timestamp
    wp_die();
}

function verify_otp_function() {
    // Verify nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'otp_verification_nonce')) {
        echo 'Invalid request.';
        wp_die();
    }

    $user_id = get_current_user_id();
    if ($user_id == 0) {
        echo 'User not logged in.';
        wp_die();
    }

    $type = sanitize_text_field($_POST['type']);
    $entered_otp = sanitize_text_field($_POST['otp']);
    $otp_meta_key = ($type === 'email') ? 'email_verification_otp' : 'phone_verification_otp';
    $time_meta_key = ($type === 'email') ? 'email_otp_sent_time' : 'phone_otp_sent_time';

    $saved_otp = get_user_meta($user_id, $otp_meta_key, true);
    $otp_sent_time = get_user_meta($user_id, $time_meta_key, true);

    $otp_expiry = 300; // Expiry in seconds (5 minutes)

    if (!$otp_sent_time || (time() - $otp_sent_time) > $otp_expiry) {
        // OTP expired
        delete_user_meta($user_id, $otp_meta_key);
        delete_user_meta($user_id, $time_meta_key);
        echo 'The OTP has expired. Please request a new one.';
        wp_die();
    }

    if ($entered_otp == $saved_otp) {
        // Successful verification
        delete_user_meta($user_id, $otp_meta_key);
        delete_user_meta($user_id, $time_meta_key);

        $verification_key = ($type === 'email') ? 'email_verified' : 'phone_verified';
        update_user_meta($user_id, $verification_key, true);

        echo ucfirst($type) . ' verified successfully.';
    } else {
        echo 'Invalid OTP. Please try again.';
    }

    wp_die();
}
