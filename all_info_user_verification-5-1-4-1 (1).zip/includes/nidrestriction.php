<?php
// add_action('template_redirect', 'redirect_if_nid_not_uploaded');

// function redirect_if_nid_not_uploaded() {
//     if (is_user_logged_in()) {
//         $user_id = get_current_user_id();
//         $nid_uploaded = get_user_meta($user_id, 'nid_uploaded', true);

//         // Exclude verification page to prevent infinite redirects
//         if (is_page('verification')) {
//             return;
//         }

//         // Pages where NID upload is required
//         $restricted_pages = ['dashboard', 'some-other-restricted-page']; // Page slugs

//         // Redirect if user hasn't uploaded NID
//         if (!$nid_uploaded && is_page($restricted_pages)) {
//             wp_redirect(home_url('/verification')); // Redirect to the verification page
//             exit;
//         }
//     }
// } 





// add_action('template_redirect', 'redirect_if_user_not_verified');

// function redirect_if_user_not_verified() {
//     if (is_user_logged_in()) {
//         $user_id = get_current_user_id();
//         $user_status = get_user_meta($user_id, 'user_status', true); // Get user status

//         // Allow access to the verification page
//         if (is_page('verification')) {
//             return;
//         }

//         // Check if the current URL contains '/lesson/' or matches any restricted page
//         $current_url = $_SERVER['REQUEST_URI'];

//         // If user status is 'active', allow access to lesson pages
//         if ($user_status !== 'active' && strpos($current_url, '/lesson/') !== false) {
//             wp_redirect(home_url('/verification')); // Redirect to the verification page if not active
//             exit;
//         }
//     }
// }







// add_action('template_redirect', 'redirect_if_user_not_verified');

// function redirect_if_user_not_verified() {
//     if (is_user_logged_in()) {
//         $user_id = get_current_user_id();
//         $user = get_userdata($user_id);

//         // Check if the user registered on or after 31/12/2024
//         $registration_date = strtotime($user->user_registered);
//         $cutoff_date = strtotime('2024-12-31');

//         if ($registration_date <= $cutoff_date) {
//             // If the user registered before the cutoff date, allow access
//             return;
//         }

//         $user_status = get_user_meta($user_id, 'user_status', true); // Get user status

//         // Allow access to the verification page
//         if (is_page('verification')) {
//             return;
//         }

//         // Check if the current URL contains '/lesson/' or matches any restricted page
//         $current_url = $_SERVER['REQUEST_URI'];

//         // If user status is 'active', allow access to lesson pages
//         if ($user_status !== 'active' && strpos($current_url, '/lesson/') !== false) {
//             wp_redirect(home_url('/verification')); // Redirect to the verification page if not active
//             exit;
//         }
//     }
// }



add_action('template_redirect', 'redirect_if_user_not_verified');

function redirect_if_user_not_verified() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $user_status = get_user_meta($user_id, 'user_status', true); // Get user status

        // Allow access to the verification page
        if (is_page('verification')) {
            return;
        }

        // Check if the current URL contains '/lesson/'
        $current_url = $_SERVER['REQUEST_URI'];

        // If user status is not 'active', redirect to the verification page
        if ($user_status !== 'active' && strpos($current_url, '/lesson/') !== false) {
            wp_redirect(home_url('/verification')); // Redirect to the verification page
            exit;
        }
    }
}



add_action('template_redirect', 'restrict_dashboard_access');

function restrict_dashboard_access() {
    if (is_page('dashboard') && is_user_logged_in()) {
        $current_user = wp_get_current_user();

        // Check if NID and profile picture are uploaded
        $nid_uploaded = get_user_meta($current_user->ID, 'nid_uploaded', true);
        $profile_picture = get_user_meta($current_user->ID, 'profile_picture', true);

        // Redirect to NID upload page if requirements are not met
        if (!$nid_uploaded || empty($profile_picture)) {
            wp_redirect(home_url('/verification')); // Replace with your NID upload page slug
            exit;
        }
    }
}




















