<?php
// Shortcode for NID Upload Page
add_shortcode('nid_upload_form', 'nid_upload_form_shortcode');

function nid_upload_form_shortcode() {
    if (!is_user_logged_in()) {
        wp_redirect(home_url('/dashboard'));
        exit;
    }

    $current_user = wp_get_current_user();

    // Check if email is verified and phone is verified
    if (!is_email_verified($current_user) || !is_phone_verified($current_user)) {
        return 'Please verify your email and phone before uploading your NID.';
    }

    $nid_uploaded = get_user_meta($current_user->ID, 'nid_uploaded', true);

    if ($nid_uploaded) {
        // Redirect to a specific page
        wp_redirect(home_url('/dashboard'));
        exit;
    }

    // Generate nonce
    $nonce = wp_create_nonce('upload_nid_nonce');

    ob_start();
    ?>
<div class="nid-upload-container" style="max-width: 500px; margin: 40px auto; padding: 25px; background-color: #ffffff; border: 1px solid #e0e0e0; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); font-family: 'Segoe UI', sans-serif;">
    <h2 style=" color: #333; margin-bottom: 20px; font-size: 20px; font-weight: 600;">Upload Your National ID</h2>
    <form id="nid-upload-form" enctype="multipart/form-data">
        
        <!-- Profile Picture Upload -->
        <div style="margin-bottom: 20px;">
            <label for="profile_picture" style="display: block; font-size: 16px; margin-bottom: 10px;">Upload Your Picture:</label>
            <input type="file" id="profile_picture" name="profile_picture" style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc; font-size: 14px; margin-bottom: 5px;" required>
            <p>The maximum file upload size will be <b>1MB.</b></p>
        </div>
        
        <!-- NID File Upload -->
        <label for="nid_file" style="display: block; font-size: 16px; margin-bottom: 10px;" id="nid-label">Upload NID:</label>
        <input type="file" id="nid_file" name="nid_file" style="width: 100%; padding: 10px;border-radius: 4px; border: 1px solid #ccc; font-size: 14px; margin-bottom: 5px;">
        <p>The maximum file upload size will be <b>1MB.</b></p>

        <!-- Checkbox for Parent's NID -->
        <div style="margin-bottom: 15px;">
            <input type="checkbox" id="is_parent_nid" name="is_parent_nid" style="margin-right: 10px; accent-color: #6e03ef;">
            <label for="is_parent_nid" style="font-size: 14px; color: #555;">Click here if you don't have a NID.</label>
        </div>

        <!-- Birth Certificate Upload -->
        <div id="birth-certificate-container" style="display: none; margin-bottom: 20px;">
            <label for="birth_certificate" style="display: block; font-size: 14px; margin-bottom: 8px; color: #555;">Birth Certificate:</label>
            <input type="file" id="birth_certificate" name="birth_certificate" style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc; font-size: 14px;margin-bottom: 5px;">
            <p>The maximum file upload size will be <b>1MB.</b></p>
        </div>

        

        <!-- Hidden Security Field -->
        <input type="hidden" name="security" value="<?php echo $nonce; ?>">

        <!-- Submit Button -->
        <button type="button" id="upload-nid-btn" style="width: 100%; background-color: #6e03ef; color: #fff; border: none; padding: 12px; border-radius: 4px; font-size: 16px; font-weight: 500; cursor: pointer;">Upload</button>

        <!-- Result Message -->
        <div id="nid-upload-result" style="margin-top: 15px; font-size: 14px; color: #666; text-align: center;"></div>
    </form>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    // Handle checkbox state change
    $('#is_parent_nid').change(function() {
        if ($(this).is(':checked')) {
            $('#nid-label').text('Upload Parent\'s NID:');
            $('#birth-certificate-container').show();
        } else {
            $('#nid-label').text('Upload NID:');
            $('#birth-certificate-container').hide();
        }
    });

    // Handle file upload button click
    $('#upload-nid-btn').click(function() {
        var nid_file = $('#nid_file').prop('files')[0];
        var birth_certificate = $('#birth_certificate').prop('files')[0];
        var profile_picture = $('#profile_picture').prop('files')[0];

        if (!nid_file) {
            alert('Please select the NID file to upload.');
            return;
        }
        if (!profile_picture) {
            alert('Please select a profile picture to upload.');
            return;
        }

        // Prepare form data
        var form_data = new FormData();
        form_data.append('action', 'upload_nid');
        form_data.append('nid_file', nid_file);

        if ($('#is_parent_nid').is(':checked')) {
            if (!birth_certificate) {
                alert('Please upload the birth certificate.');
                return;
            }
            form_data.append('birth_certificate', birth_certificate);
        }

        if (profile_picture) {
            form_data.append('profile_picture', profile_picture);
        }

        form_data.append('security', $('input[name="security"]').val());

        $.ajax({
            url: '<?php echo admin_url("admin-ajax.php"); ?>',
            type: 'POST',
            data: form_data,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    $('#nid-upload-result').html('<p>' + response.data.message + '</p>');
                    window.location.href = response.data.redirect_url;
                } else {
                    $('#nid-upload-result').html('<p style="color: red;">' + response.data.message + '</p>');
                }
            },
            error: function(xhr, status, error) {
                $('#nid-upload-result').html('<p style="color: red;">Error: ' + error + '</p>');
            }
        });
    });
});
</script>

<?php
    return ob_get_clean();
}

// AJAX handler for uploading files
add_action('wp_ajax_upload_nid', 'handle_nid_upload');
function handle_nid_upload() {
    if (!check_ajax_referer('upload_nid_nonce', 'security', false)) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }

    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(['message' => 'User not logged in.']);
    }

    if (!empty($_FILES['nid_file']['name'])) {
        $nid_file = $_FILES['nid_file'];
        $nid_file_url = handle_file_upload($nid_file);
        if ($nid_file_url) {
            update_user_meta($user_id, 'nid_uploaded', true);
            update_user_meta($user_id, 'nid_file_url', $nid_file_url);
        }
    }

    if (!empty($_FILES['profile_picture']['name'])) {
        $profile_picture = $_FILES['profile_picture'];
        $profile_picture_url = handle_file_upload($profile_picture);
        if ($profile_picture_url) {
            update_user_meta($user_id, 'profile_picture', $profile_picture_url);
        }
    }

    wp_send_json_success(['message' => 'Files uploaded successfully!', 'redirect_url' => home_url('/dashboard')]);
}

// Helper function to handle file upload
function handle_file_upload($file) {
    $upload = wp_handle_upload($file, ['test_form' => false]);
    if (!empty($upload['url'])) {
        return $upload['url'];
    }
    return false;
}


// function handle_file_upload($file) {
//     // Check file size (1MB = 1048576 bytes)
//     if ($file['size'] > 1048576) {
//         return false; // File size exceeds the limit
//     }

//     $upload = wp_handle_upload($file, ['test_form' => false]);
//     if (!empty($upload['url'])) {
//         return $upload['url'];
//     }
//     return false;
// }




// Helper functions for email and phone verification
function is_email_verified($user) {
    return get_user_meta($user->ID, 'email_verified', true) === '1';
}

function is_phone_verified($user) {
    return get_user_meta($user->ID, 'phone_verified', true) === '1';
}





// Add Profile Picture field to user profile in the admin panel
add_action('show_user_profile', 'add_profile_picture_field');
add_action('edit_user_profile', 'add_profile_picture_field');

function add_profile_picture_field($user) {
    $profile_picture = get_user_meta($user->ID, 'profile_picture', true);
    ?>
    <h3>Profile Picture</h3>
    <table class="form-table">
        <tr>
            <th><label for="profile_picture">Profile Picture</label></th>
            <td>
                <?php if ($profile_picture): ?>
                    <img src="<?php echo esc_url($profile_picture); ?>" alt="Profile Picture" style="width: 100px; height: 100px; border-radius: 50%; margin-bottom: 10px;">
                <?php endif; ?>
                <input type="file" name="profile_picture" id="profile_picture">
                <br>
                <span class="description">Upload a profile picture for this user.</span>
            </td>
        </tr>
    </table>
    <?php
}

// Save Profile Picture when user profile is updated
add_action('personal_options_update', 'save_profile_picture');
add_action('edit_user_profile_update', 'save_profile_picture');

function save_profile_picture($user_id) {
    // Verify current user permissions
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Handle file upload if a new file is provided
    if (!empty($_FILES['profile_picture']['name'])) {
        $file = $_FILES['profile_picture'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (!isset($upload['error']) && isset($upload['url'])) {
            update_user_meta($user_id, 'profile_picture', esc_url($upload['url']));
        }
    }
}

// Override the default WordPress avatar with the profile picture
add_filter('get_avatar', 'custom_user_avatar', 10, 5);

function custom_user_avatar($avatar, $id_or_email, $size, $default, $alt) {
    $user = false;

    if (is_numeric($id_or_email)) {
        $user = get_user_by('id', $id_or_email);
    } elseif (is_object($id_or_email) && !empty($id_or_email->user_id)) {
        $user = get_user_by('id', $id_or_email->user_id);
    } elseif (is_string($id_or_email)) {
        $user = get_user_by('email', $id_or_email);
    }

    if ($user) {
        $profile_picture = get_user_meta($user->ID, 'profile_picture', true);
        if ($profile_picture) {
            return '<img src="' . esc_url($profile_picture) . '" alt="' . esc_attr($alt) . '" class="avatar avatar-' . esc_attr($size) . '" style="width:' . esc_attr($size) . 'px;height:' . esc_attr($size) . 'px;border-radius:50%;">';
        }
    }

    return $avatar;
}



















