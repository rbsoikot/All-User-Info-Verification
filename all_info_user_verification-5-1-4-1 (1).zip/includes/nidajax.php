<?php

// AJAX Handler for NID and Birth Certificate Upload
add_action('wp_ajax_upload_nid', 'upload_nid_function');

function upload_nid_function() {
    $user_id = get_current_user_id();

    if ($user_id == 0) {
        wp_send_json_error(['message' => 'User not logged in.']);
    }

    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'upload_nid_nonce')) {
        wp_send_json_error(['message' => 'Nonce verification failed.']);
    }

    // Check if the user's email and phone are verified
    $user = get_user_by('id', $user_id);
    if (!is_email_verified($user) || !is_phone_verified($user)) {
        wp_send_json_error(['message' => 'Please verify your email and phone before uploading NID.']);
    }

    // Handle NID file upload
    if (!isset($_FILES['nid_file'])) {
        wp_send_json_error(['message' => 'No NID file uploaded.']);
    }

    $nid_file = $_FILES['nid_file'];
    error_log('NID File received: ' . print_r($nid_file, true));

    // Validate NID file type and size
    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!in_array($nid_file['type'], $allowed_types)) {
        wp_send_json_error(['message' => 'Invalid NID file type. Only JPG, PNG, and PDF are allowed.']);
    }
    if ($nid_file['size'] > 5 * 1024 * 1024) {
        wp_send_json_error(['message' => 'NID file size exceeds 5MB limit.']);
    }

    // Handle NID file upload
    $upload_dir = wp_upload_dir();
    $upload_path = $upload_dir['basedir'] . '/nid_uploads/';
    $upload_url = $upload_dir['baseurl'] . '/nid_uploads/';

    if (!file_exists($upload_path)) {
        if (!mkdir($upload_path, 0755, true)) {
            wp_send_json_error(['message' => 'Failed to create NID upload directory.']);
        }
    }

    $nid_filename = $user_id . '-' . time() . '-nid-' . basename($nid_file['name']);
    $nid_file_path = $upload_path . $nid_filename;

    if (!move_uploaded_file($nid_file['tmp_name'], $nid_file_path)) {
        wp_send_json_error(['message' => 'Failed to upload NID file. Please try again.']);
    }

    // Save NID URL to user meta
    update_user_meta($user_id, 'nid_uploaded', true);
    update_user_meta($user_id, 'nid_file_url', $upload_url . $nid_filename);

    // Now handle Birth Certificate file upload if present
    if (isset($_FILES['birth_certificate']) && !empty($_FILES['birth_certificate']['name'])) {
        $birth_certificate = $_FILES['birth_certificate'];
        error_log('Birth Certificate File received: ' . print_r($birth_certificate, true));

        // Validate birth certificate file type and size
        $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
        if (!in_array($birth_certificate['type'], $allowed_types)) {
            wp_send_json_error(['message' => 'Invalid birth certificate file type. Only JPG, PNG, and PDF are allowed.']);
        }
        if ($birth_certificate['size'] > 5 * 1024 * 1024) {
            wp_send_json_error(['message' => 'Birth certificate file size exceeds 5MB limit.']);
        }

        // Handle birth certificate file upload
        $upload_path_birth_certificate = $upload_dir['basedir'] . '/birth_certificate_uploads/';
        $upload_url_birth_certificate = $upload_dir['baseurl'] . '/birth_certificate_uploads/';

        if (!file_exists($upload_path_birth_certificate)) {
            if (!mkdir($upload_path_birth_certificate, 0755, true)) {
                wp_send_json_error(['message' => 'Failed to create birth certificate upload directory.']);
            }
        }

        $birth_certificate_filename = $user_id . '-' . time() . '-birth-certificate-' . basename($birth_certificate['name']);
        $birth_certificate_file_path = $upload_path_birth_certificate . $birth_certificate_filename;

        if (!move_uploaded_file($birth_certificate['tmp_name'], $birth_certificate_file_path)) {
            wp_send_json_error(['message' => 'Failed to upload birth certificate file. Please try again.']);
        }

        // Save birth certificate URL to user meta
        update_user_meta($user_id, 'birth_certificate_url', $upload_url_birth_certificate . $birth_certificate_filename);
    }

    // Respond with success message
    wp_send_json_success([
        'message' => 'Files uploaded successfully. They will be reviewed shortly.',
        'redirect_url' => home_url('/dashboard')
    ]);

    wp_die();
}
