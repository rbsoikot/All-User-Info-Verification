<?php
/**
 * Plugin Name: All Info User Verification
 * Description: Requires email verification on the second login attempt with OTP verification.
 * Version: 1.0
 * Author: RB Soikot
 * License: GPL2
 */

// // Hook into the login process
// add_action('wp_login', 'verify_user_email_on_second_login', 10, 2);
// function verify_user_email_on_second_login($user_login, $user) {
//     $user_id = $user->ID;
//     $login_count = get_user_meta($user_id, 'login_count', true);

//     // Increment login count or initialize it
//     if (empty($login_count)) {
//         $login_count = 0;
//     }
//     $login_count++;
//     update_user_meta($user_id, 'login_count', $login_count);

//     // Redirect to verification page after second login attempt
//     if ($login_count >= 2 && !get_user_meta($user_id, 'email_verified', true)) {
//         wp_redirect(home_url('/email-verification'));
//         exit;
//     }
// }


// add_action('woocommerce_order_status_completed', 'track_user_purchase_date', 10, 1);

// function track_user_purchase_date($order_id) {
//     $order = wc_get_order($order_id);
//     $user_id = $order->get_user_id();
//     $order_date = $order->get_date_completed();

//     // Define an array of target product IDs or SKUs
//     $target_product_ids = [21008, 20943, 19510, 21786 ];  // Replace with your product IDs
//     $target_product_skus = ['SEOExcellence1', 'MetaMarketing1', 'ClientHunting1', 'vod5'];  // Replace with your product SKUs

//     // Check if the order contains any of the target products
//     $contains_target_product = false;

//     foreach ($order->get_items() as $item_id => $item) {
//         // Check if the product ID or SKU matches the target ones
//         if (in_array($item->get_product_id(), $target_product_ids) || in_array($item->get_product()->get_sku(), $target_product_skus)) {
//             $contains_target_product = true;
//             break;
//         }
//     }

//     // Check if the order date is after 1st Jan 2025 and if the order contains any of the target products
//     $target_date = strtotime('2025-01-01');

//     if ($contains_target_product && $order_date && strtotime($order_date) > $target_date) {
//         // Store the purchase date in user meta
//         update_user_meta($user_id, 'purchase_after_2025', true);
//     }
// }

// // Ensure the user verification code is included
// function is_purchase_after_2025($user_id) {
//     $purchase_after_2025 = get_user_meta($user_id, 'purchase_after_2025', true);
//     return !empty($purchase_after_2025);
// }

// add_action('init', 'check_user_purchase_and_enable_plugin', 10);

// function check_user_purchase_and_enable_plugin() {
//     // Check if the user is logged in
//     if (is_user_logged_in()) {
//         $user_id = get_current_user_id();
        
//         // Check if the user has purchased any of the target products
//         if (has_user_purchased_target_products($user_id)) {
//             // Include plugin files if the user meets the criteria
//             require_once plugin_dir_path(__FILE__) . 'includes/restriction.php';
//             require_once plugin_dir_path(__FILE__) . 'includes/verificationform.php';
//             require_once plugin_dir_path(__FILE__) . 'includes/nidpage.php';
//             require_once plugin_dir_path(__FILE__) . 'includes/nidajax.php';
//             require_once plugin_dir_path(__FILE__) . 'includes/nidrestriction.php';
//         }
//     }
// }

// require_once plugin_dir_path(__FILE__) . 'includes/ajax.php';
// require_once plugin_dir_path(__FILE__) . 'includes/admin.php';
// require_once plugin_dir_path(__FILE__) . 'includes/madduser.php';
// require_once plugin_dir_path(__FILE__) . 'includes/removeuser.php';

// // Check if the user has purchased the target products
// function has_user_purchased_target_products($user_id) {
//     $orders = wc_get_orders([
//         'customer' => $user_id,
//         'post_status' => 'completed',
//     ]);

//     $target_product_ids = [21008 , 20943 , 19510, 21786  ];  // Replace with your product IDs
//     $target_product_skus = ['SEOExcellence1', 'MetaMarketing1', 'ClientHunting1', ];  // Replace with your product SKUs

//     foreach ($orders as $order) {
//         foreach ($order->get_items() as $item) {
//             // Check if the product ID or SKU matches the target ones
//             if (in_array($item->get_product_id(), $target_product_ids) || in_array($item->get_product()->get_sku(), $target_product_skus)) {
//                 return true;
//             }
//         }
//     }
//     return false;
// }











add_action('woocommerce_order_status_completed', 'track_user_purchase_date', 10, 1);

function track_user_purchase_date($order_id) {
    $order = wc_get_order($order_id);
    $user_id = $order->get_user_id();
    $order_date = $order->get_date_completed();

    $target_products = get_target_products();

    $contains_target_product = false;
    foreach ($order->get_items() as $item_id => $item) {
        if (in_array($item->get_product_id(), $target_products['product_ids']) || in_array($item->get_product()->get_sku(), $target_products['product_skus'])) {
            $contains_target_product = true;
            break;
        }
    }

    $target_date = strtotime('2025-01-01');
    if ($contains_target_product && $order_date && strtotime($order_date) > $target_date) {
        update_user_meta($user_id, 'purchase_after_2025', true);
    }
}

// Get target product IDs and SKUs
function get_target_products() {
    $product_ids = explode(',', get_option('target_product_ids', '21008, 20943, 19510, 21786'));
    $product_skus = explode(',', get_option('target_product_skus', 'SEOExcellence1, MetaMarketing1, ClientHunting1, vod5 '));

    return [
        'product_ids' => array_map('trim', $product_ids),
        'product_skus' => array_map('trim', $product_skus),
    ];
}

// Ensure the user verification code is included
function is_purchase_after_2025($user_id) {
    $purchase_after_2025 = get_user_meta($user_id, 'purchase_after_2025', true);
    return !empty($purchase_after_2025);
}

add_action('init', 'check_user_purchase_and_enable_plugin', 10);

function check_user_purchase_and_enable_plugin() {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        
        // Check if the user has purchased any of the target products
        if (has_user_purchased_target_products($user_id)) {
            // Include plugin files if the user meets the criteria
            require_once plugin_dir_path(__FILE__) . 'includes/restriction.php';
            require_once plugin_dir_path(__FILE__) . 'includes/verificationform.php';
            require_once plugin_dir_path(__FILE__) . 'includes/nidpage.php';
            require_once plugin_dir_path(__FILE__) . 'includes/nidajax.php';
            require_once plugin_dir_path(__FILE__) . 'includes/nidrestriction.php';
        }
    }
}

require_once plugin_dir_path(__FILE__) . 'includes/ajax.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin.php';
require_once plugin_dir_path(__FILE__) . 'includes/madduser.php';
require_once plugin_dir_path(__FILE__) . 'includes/removeuser.php';

// Check if the user has purchased the target products
// Update your functions to use the dynamic settings
function has_user_purchased_target_products($user_id) {
    $target_products = get_target_products();
    $orders = wc_get_orders([
        'customer' => $user_id,
        'post_status' => 'completed',
    ]);

    foreach ($orders as $order) {
        foreach ($order->get_items() as $item) {
            if (in_array($item->get_product_id(), $target_products['product_ids']) || in_array($item->get_product()->get_sku(), $target_products['product_skus'])) {
                return true;
            }
        }
    }
    return false;
}
































// Ensure the user verification code is included
// require_once plugin_dir_path(__FILE__) . 'includes/restriction.php';
// require_once plugin_dir_path(__FILE__) . 'includes/verificationform.php';
// require_once plugin_dir_path(__FILE__) . 'includes/ajax.php';
// require_once plugin_dir_path(__FILE__) . 'includes/admin.php';
// require_once plugin_dir_path(__FILE__) . 'includes/madduser.php';
// require_once plugin_dir_path(__FILE__) . 'includes/removeuser.php';
// require_once plugin_dir_path(__FILE__) . 'includes/nidpage.php';
// require_once plugin_dir_path(__FILE__) . 'includes/nidajax.php';
// require_once plugin_dir_path(__FILE__) . 'includes/nidrestriction.php';


const API_TOKEN = "say76fv0-fcflvzzv-kugbwe7k-4zksrodj-iotqekfy"; // Your API token here
const SID = "MEXEMYMASK"; // Your SID here
const DOMAIN = "https://smsplus.sslwireless.com"; // API domain URL



// Send SMS using ISMS Plus
function send_sms($msisdn, $messageBody, $csmsId) {
    $params = [
        "api_token" => API_TOKEN,
        "sid" => SID,
        "msisdn" => $msisdn,
        "sms" => $messageBody,
        "csms_id" => $csmsId
    ];

    $url = trim(DOMAIN, '/')."/api/v3/send-sms";
    $params = json_encode($params);

    return json_decode(callApi($url, $params), true);
}

// cURL function to call the ISMS API
function callApi($url, $params) {
    $ch = curl_init(); // Initialize cURL
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen($params),
        'accept:application/json'
    ));

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

// Add a custom menu in the admin panel
add_action('admin_menu', 'add_verified_users_menu');

function add_verified_users_menu() {
    // Main menu for Verified Users
    add_menu_page(
        'Verified Users', // Page title
        'Verified Users', // Menu title
        'manage_options', // Capability required to access this menu
        'verified-users', // Menu slug
        'display_verified_users', // Function to display the page
        'dashicons-admin-users', // Icon
        20 // Position
    );

    // Sub-menu for adding a Verified User manually
    add_submenu_page(
        'verified-users', // Parent slug
        'Add Verified User', // Page title
        'Add Verified User', // Menu title
        'manage_options', // Capability required to access this menu
        'add-verified-user', // Sub-menu slug
        'add_verified_user_form' // Function to display the sub-menu page
    );
    // Sub-menu for settings
    add_submenu_page(
        'verified-users', // Parent slug
        'Target Products Settings', // Page title
        'Product Settings', // Menu title
        'manage_options', // Capability required to access this menu
        'target-products-settings', // Sub-menu slug
        'display_target_products_settings' // Function to display the settings page
    );
}






// Display the settings page
function display_target_products_settings() {
    // Check if the form is submitted
    if (isset($_POST['save_target_products_settings'])) {
        // Save the product IDs and SKUs to options
        $product_ids = sanitize_text_field($_POST['target_product_ids']);
        $product_skus = sanitize_text_field($_POST['target_product_skus']);
        
        update_option('target_product_ids', $product_ids);
        update_option('target_product_skus', $product_skus);

        echo '<div class="updated"><p>Settings saved successfully!</p></div>';
    }

    // Get the current values from options
    $product_ids = get_option('target_product_ids', '21008, 20943, 19510, 21786');
    $product_skus = get_option('target_product_skus', 'SEOExcellence1, MetaMarketing1, ClientHunting1, vod5 ');
    
    ?>
    <div class="wrap">
        <h1>Target Products Settings</h1>
        <form method="POST" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="target_product_ids">Product IDs</label></th>
                    <td>
                        <input type="text" id="target_product_ids" name="target_product_ids" value="<?php echo esc_attr($product_ids); ?>" class="regular-text">
                        <p class="description">Enter the product IDs, separated by commas.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="target_product_skus">Product SKUs</label></th>
                    <td>
                        <input type="text" id="target_product_skus" name="target_product_skus" value="<?php echo esc_attr($product_skus); ?>" class="regular-text">
                        <p class="description">Enter the product SKUs, separated by commas.</p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="save_target_products_settings" id="save_target_products_settings" class="button button-primary" value="Save Changes">
            </p>
        </form>
    </div>
    <?php
}























// Handle the AJAX request to enable the system
add_action('wp_ajax_enable_system_for_user', 'enable_system_for_user');

function enable_system_for_user() {
    // Check for nonce verification
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'enable_system_nonce')) {
        wp_send_json_error(array('message' => 'Nonce verification failed.'));
        exit;
    }

    // Check for the user_id passed via AJAX
    if (isset($_POST['user_id'])) {
        $user_id = intval($_POST['user_id']);

        // Ensure the user exists
        if (get_user_by('id', $user_id)) {
            // Update the user meta to enable the system
            update_user_meta($user_id, 'purchase_after_2025', true);

            // Send a success response
            wp_send_json_success(array('message' => 'The system has been enabled for you.'));
        } else {
            wp_send_json_error(array('message' => 'User not found.'));
        }
    } else {
        wp_send_json_error(array('message' => 'Invalid user ID.'));
    }
}







// Add a shortcode to display the enable system button
function add_system_enable_button_shortcode() {
    ob_start();
    ?>
    <a href="javascript:void(0);" class="enable-system-link" id="enable_system_button" style="font-size:13px;">Verify Yourself</a>
    <span id="enable_system_status" style="display:none; color:green;">The system has been enabled for you!</span>
    <script>
    jQuery(document).ready(function($) {
        var ajaxurl = '<?php echo admin_url("admin-ajax.php"); ?>'; // Ensure ajaxurl is defined

        $('#enable_system_button').on('click', function() {
            var user_id = <?php echo get_current_user_id(); ?>;

            // Create nonce for security
            var nonce = '<?php echo wp_create_nonce('enable_system_nonce'); ?>';

            // Display confirmation dialog
            var confirmation = confirm("Are you sure you want to verify yourself? This action cannot be undone. Proceed with verification?");
            if (!confirmation) {
                return; // Exit if user cancels
            }

            console.log('User ID: ' + user_id);
            console.log('Nonce: ' + nonce);

            $.post(ajaxurl, {
                action: 'enable_system_for_user',
                user_id: user_id,
                nonce: nonce  // Include nonce for security
            }, function(response) {
                console.log(response);  // Log the response for debugging
                
                if (response.success) {
                    // Redirect the user to the email verification page
                    window.location.href = 'https://mexemy.com/email-and-phone-verification/';
                } else {
                    alert('Failed to enable the system. Please try again.');
                }
            }).fail(function(xhr, status, error) {
                console.error('AJAX request failed:', status, error);
                alert('AJAX request failed: ' + status + ' - ' + error);
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('enable_system_button', 'add_system_enable_button_shortcode');









// Ensure jQuery is loaded on the frontend
function load_custom_scripts() {
    wp_enqueue_script('jquery');  // Enqueue jQuery
}
add_action('wp_enqueue_scripts', 'load_custom_scripts');
















