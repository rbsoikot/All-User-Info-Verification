jQuery(document).ready(function ($) {
    $('#enable-system-btn').on('click', function () {
        if (confirm('Are you sure you want to enable the system?')) {
            $.ajax({
                url: enableSystemAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'enable_system',
                    nonce: enableSystemAjax.nonce,
                },
                success: function (response) {
                    alert(response.message);
                    if (response.success) {
                        location.reload();
                    }
                },
                error: function () {
                    alert('An error occurred. Please try again.');
                },
            });
        }
    });
});
